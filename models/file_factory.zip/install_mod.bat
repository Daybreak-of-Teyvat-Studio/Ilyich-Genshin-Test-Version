@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -Command "$env:AL_PKG='%~dp0'; $s=[IO.File]::ReadAllText('%~f0'); iex ($s.Substring($s.IndexOf('#PS'+'-BEGIN')+9))"
endlocal
exit /b %errorlevel%
#PS-BEGIN
$ErrorActionPreference = 'Stop'
$pkg = $env:AL_PKG
$modName = 'asset_lab_bundle'
$installId = 'asset_lab_bundle_20261028_162811_ea00c3a9c1a9448da9fc525a81065238'

# 提示语言:包会发到广场给别人装,按这台机器的显示语言选;
# HOI4_ASSETLAB_LANG 供测试 / 排障强制指定(与 HOI4_USER_ROOT 同类)
$I18N = @{
  'en' = @{ 'title' = '== HOI4 Asset Lab · Installer =='; 'failed' = '[FAILED] {message}'; 'pressEnter' = 'Press Enter to close'; 'incompletePackage' = 'The archive is incomplete: {path} is missing. Extract the whole zip, then run the bat from the extracted folder.'; 'noUserRoot' = 'Cannot find the HOI4 user folder. Start the game once, or set the HOI4_USER_ROOT environment variable to point at it.'; 'userRoot' = 'User folder   {path}'; 'confirmOverwrite' = '{path} already exists. Overwrite it? (Y/N)'; 'cancelled' = 'Cancelled.'; 'gameVersion' = 'Game version  {raw}  ->  supported_version="{version}"'; 'installOk' = '[DONE] Installed'; 'modDir' = '  Mod folder       {path}'; 'descriptorFile' = '  Descriptor file  {path}'; 'askLaunch' = 'Enable only this mod and launch the game now? (Y/N)'; 'answerYN' = 'Please type Y (yes) or N (no). You can also answer in your own language.'; 'launching' = 'Launching the game (bypassing the Paradox Launcher, which would otherwise overwrite the mod selection above)...'; 'noExe' = 'hoi4.exe not found. Please start the game yourself; if you use the Paradox Launcher, tick this mod there.'; 'enableInLauncher' = 'Tick this mod in the Paradox Launcher to enable it.'; 'errorLog' = 'If something goes wrong, check {path}' }
  'zh' = @{ 'title' = '== HOI4 Asset Lab · 安装器 =='; 'failed' = '[失败] {message}'; 'pressEnter' = '按回车关闭'; 'incompletePackage' = '压缩包不完整，找不到 {path}。请把 zip 整个解压后，运行解压出来的这个 bat。'; 'noUserRoot' = '找不到 HOI4 用户目录。请先启动一次游戏，或设置环境变量 HOI4_USER_ROOT 指向它。'; 'userRoot' = '用户目录  {path}'; 'confirmOverwrite' = '{path} 已存在，覆盖它吗？(Y/N)'; 'cancelled' = '已取消。'; 'gameVersion' = '游戏版本  {raw}  ->  supported_version="{version}"'; 'installOk' = '[完成] 安装成功'; 'modDir' = '  MOD 目录  {path}'; 'descriptorFile' = '  描述文件  {path}'; 'askLaunch' = '现在只启用这个 MOD 并直接启动游戏吗？(Y/N)'; 'answerYN' = '请输入 Y（是）或 N（否），也可以用你的语言回答。'; 'launching' = '正在启动游戏（跳过 Paradox 启动器，否则上面的 MOD 选择会被启动器覆盖）...'; 'noExe' = '找不到 hoi4.exe，请手动启动。注意从 Paradox 启动器进游戏要自己在启动器里勾选本 MOD。'; 'enableInLauncher' = '在 Paradox 启动器里勾选本 MOD 即可。'; 'errorLog' = '出问题就看  {path}' }
  'de' = @{ 'title' = '== HOI4 Asset Lab · Installer =='; 'failed' = '[FEHLER] {message}'; 'pressEnter' = 'Drücken Sie die Eingabetaste, um das Fenster zu schließen'; 'incompletePackage' = 'Das Archiv ist unvollständig: {path} fehlt. Entpacken Sie die gesamte ZIP-Datei und starten Sie die BAT-Datei aus dem entpackten Ordner.'; 'noUserRoot' = 'Der HOI4-Benutzerordner wurde nicht gefunden. Starten Sie das Spiel einmal oder geben Sie den Ordner mit der Umgebungsvariable HOI4_USER_ROOT an.'; 'userRoot' = 'Benutzerordner  {path}'; 'confirmOverwrite' = '{path} ist bereits vorhanden. Überschreiben? (Y/N)'; 'cancelled' = 'Abgebrochen.'; 'gameVersion' = 'Spielversion    {raw}  ->  supported_version="{version}"'; 'installOk' = '[FERTIG] Installation abgeschlossen'; 'modDir' = '  Mod-Ordner          {path}'; 'descriptorFile' = '  Beschreibungsdatei  {path}'; 'askLaunch' = 'Nur diese Mod aktivieren und das Spiel jetzt starten? (Y/N)'; 'answerYN' = 'Bitte geben Sie Y (ja) oder N (nein) ein. Sie können auch in Ihrer Sprache antworten.'; 'launching' = 'Das Spiel wird gestartet (ohne Paradox Launcher, da dieser die obige Mod-Auswahl sonst überschreiben würde)...'; 'noExe' = 'hoi4.exe wurde nicht gefunden. Bitte starten Sie das Spiel selbst; wenn Sie den Paradox Launcher verwenden, setzen Sie dort ein Häkchen bei dieser Mod.'; 'enableInLauncher' = 'Setzen Sie im Paradox Launcher ein Häkchen bei dieser Mod, um sie zu aktivieren.'; 'errorLog' = 'Falls etwas schiefgeht, prüfen Sie {path}' }
  'es' = @{ 'title' = '== HOI4 Asset Lab · Instalador =='; 'failed' = '[ERROR] {message}'; 'pressEnter' = 'Pulsa Intro para cerrar'; 'incompletePackage' = 'El archivo comprimido está incompleto: falta {path}. Extrae el zip completo y ejecuta el bat desde la carpeta extraída.'; 'noUserRoot' = 'No se encuentra la carpeta de usuario de HOI4. Inicia el juego una vez o define la variable de entorno HOI4_USER_ROOT con la ruta de esa carpeta.'; 'userRoot' = 'Carpeta de usuario  {path}'; 'confirmOverwrite' = '{path} ya existe. ¿Quieres sobrescribirlo? (Y/N)'; 'cancelled' = 'Cancelado.'; 'gameVersion' = 'Versión del juego   {raw}  ->  supported_version="{version}"'; 'installOk' = '[LISTO] Instalación completada'; 'modDir' = '  Carpeta del mod     {path}'; 'descriptorFile' = '  Archivo descriptor  {path}'; 'askLaunch' = '¿Activar solo este mod e iniciar el juego ahora? (Y/N)'; 'answerYN' = 'Escribe Y (sí) o N (no). También puedes responder en tu idioma.'; 'launching' = 'Iniciando el juego (sin pasar por el Paradox Launcher, que de lo contrario sobrescribiría la selección de mods anterior)...'; 'noExe' = 'No se encuentra hoi4.exe. Inicia el juego manualmente; si usas el Paradox Launcher, marca allí este mod.'; 'enableInLauncher' = 'Marca este mod en el Paradox Launcher para activarlo.'; 'errorLog' = 'Si algo falla, revisa {path}' }
  'fr' = @{ 'title' = '== HOI4 Asset Lab · Programme d’’installation =='; 'failed' = '[ÉCHEC] {message}'; 'pressEnter' = 'Appuyez sur Entrée pour fermer'; 'incompletePackage' = 'L’’archive est incomplète : {path} est introuvable. Extrayez tout le zip, puis lancez le fichier bat depuis le dossier extrait.'; 'noUserRoot' = 'Dossier utilisateur de HOI4 introuvable. Lancez le jeu une fois, ou indiquez son emplacement dans la variable d’’environnement HOI4_USER_ROOT.'; 'userRoot' = 'Dossier utilisateur  {path}'; 'confirmOverwrite' = '{path} existe déjà. Écraser ce dossier ? (Y/N)'; 'cancelled' = 'Annulé.'; 'gameVersion' = 'Version du jeu       {raw}  ->  supported_version="{version}"'; 'installOk' = '[TERMINÉ] Installation réussie'; 'modDir' = '  Dossier du mod       {path}'; 'descriptorFile' = '  Fichier descripteur  {path}'; 'askLaunch' = 'Activer uniquement ce mod et lancer le jeu maintenant ? (Y/N)'; 'answerYN' = 'Tapez Y (oui) ou N (non). Vous pouvez aussi répondre dans votre langue.'; 'launching' = 'Lancement du jeu (sans passer par le Paradox Launcher, qui écraserait sinon la sélection de mods ci-dessus)...'; 'noExe' = 'hoi4.exe introuvable. Lancez le jeu vous-même ; si vous utilisez le Paradox Launcher, cochez ce mod dans le lanceur.'; 'enableInLauncher' = 'Pour activer ce mod, cochez-le dans le Paradox Launcher.'; 'errorLog' = 'En cas de problème, consultez {path}' }
  'ja' = @{ 'title' = '== HOI4 Asset Lab · インストーラー =='; 'failed' = '[失敗] {message}'; 'pressEnter' = 'Enter キーを押して閉じてください'; 'incompletePackage' = 'アーカイブが不完全です。{path} が見つかりません。zip をすべて展開してから、展開したフォルダー内の bat を実行してください。'; 'noUserRoot' = 'HOI4 のユーザーフォルダーが見つかりません。一度ゲームを起動するか、環境変数 HOI4_USER_ROOT でフォルダーを指定してください。'; 'userRoot' = 'ユーザーフォルダー  {path}'; 'confirmOverwrite' = '{path} は既に存在します。上書きしますか？(Y/N)'; 'cancelled' = 'キャンセルしました。'; 'gameVersion' = 'ゲームバージョン    {raw}  ->  supported_version="{version}"'; 'installOk' = '[完了] インストールしました'; 'modDir' = '  Mod フォルダー  {path}'; 'descriptorFile' = '  定義ファイル    {path}'; 'askLaunch' = 'この Mod だけを有効にして、今すぐゲームを起動しますか？(Y/N)'; 'answerYN' = 'Y（はい）または N（いいえ）を入力してください。日本語で答えることもできます。'; 'launching' = 'ゲームを起動しています（Paradox ランチャーは経由しません。経由すると、上で選んだ Mod がランチャーの設定で上書きされます）...'; 'noExe' = 'hoi4.exe が見つかりません。ゲームを手動で起動してください。Paradox ランチャーから起動する場合は、ランチャーでこの Mod にチェックを入れてください。'; 'enableInLauncher' = 'Paradox ランチャーでこの Mod にチェックを入れると有効になります。'; 'errorLog' = '問題が起きたときは {path} を確認してください' }
  'ko' = @{ 'title' = '== HOI4 Asset Lab · 설치 프로그램 =='; 'failed' = '[실패] {message}'; 'pressEnter' = 'Enter 키를 누르면 닫힙니다'; 'incompletePackage' = '압축 파일이 불완전합니다. {path} 파일이 없습니다. zip 파일의 압축을 모두 푼 뒤, 압축을 푼 폴더에 있는 bat 파일을 실행하세요.'; 'noUserRoot' = 'HOI4 사용자 폴더를 찾을 수 없습니다. 게임을 한 번 실행하거나 환경 변수 HOI4_USER_ROOT에 해당 폴더 경로를 지정하세요.'; 'userRoot' = '사용자 폴더  {path}'; 'confirmOverwrite' = '{path} 폴더가 이미 있습니다. 덮어쓰시겠습니까? (Y/N)'; 'cancelled' = '취소했습니다.'; 'gameVersion' = '게임 버전    {raw}  ->  supported_version="{version}"'; 'installOk' = '[완료] 설치되었습니다'; 'modDir' = '  모드 폴더  {path}'; 'descriptorFile' = '  설명 파일  {path}'; 'askLaunch' = '이 모드만 활성화하고 지금 게임을 실행하시겠습니까? (Y/N)'; 'answerYN' = 'Y(예) 또는 N(아니요)를 입력하세요. 한국어로 답해도 됩니다.'; 'launching' = '게임을 실행하는 중입니다(Paradox 런처를 거치지 않습니다. 런처를 거치면 위에서 선택한 모드가 런처 설정으로 덮어써집니다)...'; 'noExe' = 'hoi4.exe 파일을 찾을 수 없습니다. 게임을 직접 실행하세요. Paradox 런처를 사용한다면 런처에서 이 모드를 체크하세요.'; 'enableInLauncher' = 'Paradox 런처에서 이 모드를 체크하면 활성화됩니다.'; 'errorLog' = '문제가 생기면 {path} 파일을 확인하세요' }
  'ru' = @{ 'title' = '== HOI4 Asset Lab · Установщик =='; 'failed' = '[ОШИБКА] {message}'; 'pressEnter' = 'Нажмите Enter, чтобы закрыть'; 'incompletePackage' = 'Архив неполный: не найден файл {path}. Распакуйте zip целиком и запустите bat-файл из распакованной папки.'; 'noUserRoot' = 'Не найдена папка пользователя HOI4. Запустите игру хотя бы один раз или укажите путь к этой папке в переменной окружения HOI4_USER_ROOT.'; 'userRoot' = 'Папка пользователя  {path}'; 'confirmOverwrite' = '{path} уже существует. Перезаписать? (Y/N)'; 'cancelled' = 'Отменено.'; 'gameVersion' = 'Версия игры         {raw}  ->  supported_version="{version}"'; 'installOk' = '[ГОТОВО] Установка завершена'; 'modDir' = '  Папка мода     {path}'; 'descriptorFile' = '  Файл описания  {path}'; 'askLaunch' = 'Включить только этот мод и сразу запустить игру? (Y/N)'; 'answerYN' = 'Введите Y (да) или N (нет). Можно ответить и на своём языке.'; 'launching' = 'Запуск игры (в обход Paradox Launcher, иначе он перезапишет выбранные выше моды)...'; 'noExe' = 'hoi4.exe не найден. Запустите игру вручную; если вы пользуетесь Paradox Launcher, отметьте там этот мод.'; 'enableInLauncher' = 'Чтобы включить этот мод, отметьте его в Paradox Launcher.'; 'errorLog' = 'Если что-то пойдёт не так, проверьте {path}' }
}
$lang = $env:HOI4_ASSETLAB_LANG
if ($lang) { $lang = ($lang -split '[-_]')[0] } else { $lang = (Get-UICulture).TwoLetterISOLanguageName }
if (-not $I18N.ContainsKey($lang)) { $lang = 'en' }
$T = $I18N[$lang]
# 逐个参数 .Replace(Python 侧是一次扫描);多参数的只有 gameVersion,游戏版本号里不会出现 {version}
function Tr($k, $p) {
  $s = $T[$k]
  if ($null -eq $s) { $s = $k }
  if ($p) { foreach ($n in $p.Keys) { $s = $s.Replace('{' + $n + '}', [string]$p[$n]) } }
  return $s
}

# 是 / 否:直接回车 = 否;y / n 开头;再认非英文键盘布局下 Y / N 键打出的字和各语言的是 / 否
# (回答表见 server.py INSTALLER_YES / INSTALLER_NO)。其它输入重问,不再默认当「否」。
function Norm($s) {
  if ($null -eq $s) { return '' }
  return ([string]$s).Normalize([Text.NormalizationForm]::FormKC).Trim().ToLowerInvariant()
}
$YES = @(@('н', 'ㅛ', 'д', 'да', '예', '네', 'はい', '是', '是的', '对', 'ja', 'j', 'sí', 'si', 's', 'oui', 'o') | ForEach-Object { Norm $_ })
$NO = @(@('т', 'ㅜ', 'нет', '아니요', '아니오', '아니', 'いいえ', '否', '不', '不是') | ForEach-Object { Norm $_ })
function Ask($k, $p) {
  while ($true) {
    $a = Norm (Read-Host (Tr $k $p))
    if ($a -eq '' -or $a.StartsWith('n') -or $NO -contains $a) { return $false }
    if ($a.StartsWith('y') -or $YES -contains $a) { return $true }
    Write-Host (Tr 'answerYN') -ForegroundColor Yellow
  }
}

function Fail($m) { Write-Host ''; Write-Host (Tr 'failed' @{message=$m}) -ForegroundColor Red; Read-Host (Tr 'pressEnter'); exit 1 }
function Save-Text($path, $text) { [IO.File]::WriteAllText($path, $text, (New-Object Text.UTF8Encoding $false)) }

Write-Host (Tr 'title') -ForegroundColor Cyan

$src = Join-Path $pkg $modName
if (-not (Test-Path (Join-Path $src 'descriptor.mod'))) {
  Fail (Tr 'incompletePackage' @{path=($modName + '\descriptor.mod')})
}

# 1) HOI4 用户目录
$roots = @()
if ($env:HOI4_USER_ROOT) { $roots += $env:HOI4_USER_ROOT }
$roots += (Join-Path $env:USERPROFILE 'Documents\Paradox Interactive\Hearts of Iron IV')
$roots += (Join-Path $env:USERPROFILE 'OneDrive\Documents\Paradox Interactive\Hearts of Iron IV')
$userRoot = $roots | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $userRoot) { Fail (Tr 'noUserRoot') }
$modRoot = Join-Path $userRoot 'mod'
New-Item -ItemType Directory -Force -Path $modRoot | Out-Null
Write-Host (Tr 'userRoot' @{path=$userRoot})

# 2) 定位游戏安装目录：用来对齐 supported_version，并支持直接启动
$gameDir = $null
$libs = @()
$sp = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
if ($sp) {
  $sp = $sp.Replace('/', '\')
  $libs += $sp
  $vdf = Join-Path $sp 'steamapps\libraryfolders.vdf'
  if (Test-Path $vdf) {
    foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s*"([^"]+)"')) {
      $libs += $m.Groups[1].Value.Replace('\\', '\')
    }
  }
}
foreach ($l in $libs) {
  $d = Join-Path $l 'steamapps\common\Hearts of Iron IV'
  if (Test-Path (Join-Path $d 'hoi4.exe')) { $gameDir = $d; break }
}

# 3) 复制 mod 内容
$target = Join-Path $modRoot $installId
if (Test-Path $target) {
  if (-not (Ask 'confirmOverwrite' @{path=$target})) { Fail (Tr 'cancelled') }
  Remove-Item -Recurse -Force $target
}
Copy-Item -Recurse -Force $src $target

# 4) supported_version 对齐本机游戏版本
#    托管导出读不到本机版本，包里写的是服务端原版表的版本（vanilla_tables.tables_version）；
#    这里按本机 launcher-settings.json 再对一次，版本不同时以本机为准
$descFile = Join-Path $target 'descriptor.mod'
$desc = [IO.File]::ReadAllText($descFile)
if ($gameDir) {
  $ls = Join-Path $gameDir 'launcher-settings.json'
  if (Test-Path $ls) {
    # 正则取版本：这个 json 里有中日韩文，PS 5.1 的 ConvertFrom-Json 会按 ANSI 解码弄坏它
    $vm = [regex]::Match([IO.File]::ReadAllText($ls), '"rawVersion"\s*:\s*"([^"]+)"')
    $raw = $vm.Groups[1].Value
    $parts = $raw.Split('.')
    if ($parts.Count -ge 2) {
      $sv = $parts[0] + '.' + $parts[1] + '.*'
      $desc = [regex]::Replace($desc, 'supported_version\s*=\s*"[^"]*"', ('supported_version="' + $sv + '"'))
      Save-Text $descFile $desc
      Write-Host (Tr 'gameVersion' @{raw=$raw; version=$sv})
    }
  }
}

# 5) 写 mod 根目录的 .mod，path 指向本机真实路径
$descPath = Join-Path $modRoot ($installId + '.mod')
$body = $desc.TrimEnd("`r", "`n") + "`r`n" + 'path="' + $target.Replace('\', '/') + '"' + "`r`n"
Save-Text $descPath $body

Write-Host ''
Write-Host (Tr 'installOk') -ForegroundColor Green
Write-Host (Tr 'modDir' @{path=$target})
Write-Host (Tr 'descriptorFile' @{path=$descPath})
Write-Host ''

# 6) 可选：只启用本 MOD 并直接启动游戏
if (Ask 'askLaunch') {
  $dlc = Join-Path $userRoot 'dlc_load.json'
  if (Test-Path $dlc) { Copy-Item $dlc ($dlc + '.assetlab.bak') -Force }
  Save-Text $dlc ('{"disabled_dlcs":[],"enabled_mods":["mod/' + $installId + '.mod"]}')
  if ($gameDir) {
    Write-Host (Tr 'launching')
    Start-Process -FilePath (Join-Path $gameDir 'hoi4.exe') -ArgumentList '-gdpr-compliant' -WorkingDirectory $gameDir
  } else {
    Write-Host (Tr 'noExe') -ForegroundColor Yellow
  }
} else {
  Write-Host (Tr 'enableInLauncher')
}

Write-Host ''
Write-Host (Tr 'errorLog' @{path=(Join-Path $userRoot 'logs\error.log')})
Read-Host (Tr 'pressEnter')
