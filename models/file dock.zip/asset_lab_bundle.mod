version="0.1"
tags={
    "Graphics"
}
name="asset_lab_bundle (20261028_165113_b237049fa6544ea89a98b0d282882bca)"
supported_version="1.19.*"
path="mod/asset_lab_bundle"
