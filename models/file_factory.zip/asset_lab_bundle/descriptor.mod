version="0.1"
tags={
    "Graphics"
}
name="asset_lab_bundle (20261028_162811_ea00c3a9c1a9448da9fc525a81065238)"
supported_version="1.19.*"
